sap.ui.define(["sap/m/MessageToast"],function(s){"use strict";return{Submit:function(e){s.show("Custom handler invoked.")}}});
//# sourceMappingURL=Submit.js.map